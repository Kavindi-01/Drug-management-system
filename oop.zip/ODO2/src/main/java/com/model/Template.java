package com.model;

public  abstract class Template {
	
	public final void AssignAgent() {
		
		//specify the order of execution
		
		ViewOrders();
		CheckPayments();
		LocationAnalize();
		AssignTheAgent();
	}
	
	public abstract void ViewOrders();
	public abstract void CheckPayments();
	public abstract void LocationAnalize();
	public  final  void AssignTheAgent() {
		
		System.out.println(" Assign The Nearest Agent");
	}
	

}
