package com.model;

//used abstraction concept to reduce this to a set of essential characteristics that is needed for this system
//inheritance
//encapsulation
//information hiding
//agent is the sub class of User class
public class Agent extends User{

	//properties
	private String branch;
	
	
	//parameterized constructor
	
	public Agent(int id, String name, String email, String phonNumber, String branch) {
		super(id, name, email, phonNumber);
		this.branch = branch;
	}

	public String getBranch() {
		return branch;
	}

	
}
