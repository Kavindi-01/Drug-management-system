package com.model;

public class ChildTemplate extends Template {
	
	public void ViewOrders() {
		
		System.out.println(" View the orders!!!");
	}
	
	public void CheckPayments() {
		
		System.out.println(" Check payments are succeed or not");
	}

	@Override
	public void LocationAnalize() {
		// TODO Auto-generated method stub
		
	}
	
	}


