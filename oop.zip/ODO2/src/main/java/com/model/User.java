package com.model;

//used abstraction concept to reduce this to a set of essential characteristics that is needed for this system
//inheritance

//agent class is extend from user class
public class User {
	
	//used encapsulation concept
	
	//properties
	protected int id;
	protected String name;
	protected String email;
	protected String phonNumber;
	
	//parameterized constructor
	public User(int id , String name, String email, String phonNumber) {
		
		this.id = id;
		this.name = name;
		this.email = email;
		this.phonNumber = phonNumber;
	}

	//getters used for get values
	
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPhonNumber() {
		return phonNumber;
	}

	
	
	
}
