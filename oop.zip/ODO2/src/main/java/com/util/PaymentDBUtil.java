package com.util;

//manipulate data with using database

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.order;

public class PaymentDBUtil {

	public static Connection con = null;
	public static Statement stmt = null;
	public static ResultSet rs = null;
	public static boolean isSuccess;
	
	
	public static List<order> getOrders() throws SQLException{
		
		con =  DBConfig.getConnection();
		stmt = con.createStatement();
		
		ArrayList<order> arl = new ArrayList<>();
		
		//execute the quary
		
		String sql = "SELECT * FROM oop.orders";
		
		ResultSet rs = stmt.executeQuery(sql);
		
		
		while(rs.next()) {
			int id = rs.getInt("id");
			int cid = rs.getInt("cid");
			String oName = rs.getString("orderName");
			Double payment = rs.getDouble("payment");
			String location  = rs.getString("location");
			String dueDate = rs.getString("duedate");
			
			order o = new order(id, cid, oName, payment, location, dueDate);
			arl.add(o);
		}
		
		
		return arl;
		
	}
} 
