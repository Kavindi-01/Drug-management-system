package com.model;

public class order {
	
	//properties
	private int id;
	private int cid;
	private String orderName;
	private double payment;
	private String location;
	private String date;
	
	//parameterized constructor
	public order(int id, int cid, String orderName, double payment, String location, String date) {
		
		this.id = id;
		this.cid = cid;
		this.orderName = orderName;
		this.payment = payment;
		this.location = location;
		this.date = date;
	}

//getters
	public int getId() {
		return id;
	}
	
	public int getCid() {
		return cid;
	}


	public String getOrderName() {
		return orderName;
	}


	public double getPayment() {
		return payment;
	}


	public String getLocation() {
		return location;
	}


	public String getDate() {
		return date;
	}


	
	

}
