package com.model;

public class Client {

	public static void main(String[] args) {
		
		Template obj1 =new ChildTemplate();
		obj1.AssignAgent();
		System.out.println(" ----------------- ");
		
		obj1 = new ChildTemplate2();
		obj1.AssignTheAgent();
		
		
	}

}
