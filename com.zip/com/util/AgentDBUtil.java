package com.util;
//utility class is a class that defines a set of methods that perform common, often re-used functions

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.Agent;
import com.model.order;

public class AgentDBUtil {

	public static Connection con = null;
	public static Statement stmt = null;
	public static ResultSet rs = null;
	public static boolean isSuccess;
	
	
	//take agent list from database and view it 
	
	public static List<Agent> getAgent() throws SQLException{
		
		//call the method and get the db connection 
		con =  DBConfig.getConnection();
		stmt = con.createStatement();
		
		//create an array list to collect data of tuples
		ArrayList<Agent> arl = new ArrayList<>();
		
		
		String sql = "SELECT * FROM oop.agent";
		
		//store executed data in ResultSet variable
		ResultSet rs = stmt.executeQuery(sql);
		
		
		while(rs.next()) {
			int id = rs.getInt("id");
			String name = rs.getString("name");
			String email = rs.getString("email");
			String phoneNum = rs.getString("phoneNum");
			String branch = rs.getString("branch");
			
			//create an object and call for the constructor of Agent class////////////////////////////////
			Agent o = new Agent(id, name, email, phoneNum,branch );
			
			//add objects to the array list
			arl.add(o);
		}
		
		//return the array list
		return arl;
		
	}
	
	
	
	//delete Agent
	
	public static boolean deleteAgent(int id)throws SQLException {

		con =  DBConfig.getConnection();
		stmt = con.createStatement();
		
		String sql = "delete  FROM oop.agent where id='"+id+"'";
		
		int result = stmt.executeUpdate(sql);
		
		if(result == 1 ) {
			
			isSuccess = true;
		}else {
			isSuccess = false;
		}
		
		return isSuccess;
	}
	
	
}
