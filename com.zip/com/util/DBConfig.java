package com.util;

import java.sql.DriverManager;
import java.sql.Connection;

//create the database connection 

public class DBConfig {

	private static String url = "jdbc:mysql://localhost:3306/oop";
	private static String username = "root";
	private static String password = "kmfd#68A";
	
	private static Connection con;
	
	public static Connection getConnection() {
		
		//used this try catch block to identify whether the database connection is succeed or not
				
		try {
			
			//Register the driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//Create connection
			con = DriverManager.getConnection(url, username, password);
			
		}
		//if the db connection is not connected,system will print this error msg
		catch(Exception e){
			System.out.println("Database connection failed");
		}
		
		return con;
	}
}
