package com.util;
//utility class is a class that defines a set of methods that perform common, often re-used functions

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserDbUtil {
	
	public static Connection con = null;
	public static Statement stmt = null;
	public static ResultSet rs = null;
	public static boolean isSuccess;
	
	
	public static boolean insertUser(String fname, String password) throws SQLException {
		
		con =  DBConfig.getConnection();
		stmt = con.createStatement();
		
		String sql = "INSERT INTO `oop`.`user` (`uname`, `password`) VALUES ('"+fname+"', '"+password+"') ";
			
		/////read // ResultSet rs = stmt.executeQuery(sql);
		
		//execute query.. Insert data
		int result = stmt.executeUpdate(sql);
		
		if(result == 1) {
			isSuccess = true;
		}else {
			isSuccess = false;
		}
		
		return isSuccess;
	}
	
	
	//Insert Agent
	public static boolean insertAgent(String name, String email, String phoneNum, String branch) throws SQLException {
		
		con =  DBConfig.getConnection();
		stmt = con.createStatement();
		
		String sql = "INSERT INTO `oop`.`agent` (`name`, `email`, `phoneNum`, `branch`) VALUES ('"+name+"', '"+email+"', '"+phoneNum+"', '"+branch+"')";

			
		/////read // ResultSet rs = stmt.executeQuery(sql);
		
		//execute query.. Insert data
		int result = stmt.executeUpdate(sql);
		
		if(result == 1) {
			isSuccess = true;
		}else {
			isSuccess = false;
		}
		
		return isSuccess;
	}
	

}
